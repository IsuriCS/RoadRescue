create definer = admin@`%` trigger service_request_BEFORE_DELETE
    before delete
    on service_request
    for each row
BEGIN
    INSERT INTO deleted_service_request (
        id,
        customer_id,
        issue_category_id,
        indicator_1,
        indicator_2,
        indicator_3,
        indicator_4,
        indicator_5,
        indicator_6,
        vehicle_type_id,
        vehicle_make_id,
        vehicle_model_id,
        fuel_type_id,
        description,
        status,
        request_timestamp,
        accepted_timestamp,
        assigned_service_provider_id,
        updated_at,
        location,
        paid_amount,
        rating,
        approx_cost,
        requested_amount
    ) VALUES (
                OLD.id,
        OLD.customer_id,
        OLD.issue_category_id,
        OLD.indicator_1,
        OLD.indicator_2,
        OLD.indicator_3,
        OLD.indicator_4,
        OLD.indicator_5,
        OLD.indicator_6,
        OLD.vehicle_type_id,
        OLD.vehicle_make_id,
        OLD.vehicle_model_id,
        OLD.fuel_type_id,
        OLD.description,
        OLD.status,
        OLD.request_timestamp,
        OLD.accepted_timestamp,
        OLD.assigned_service_provider_id,
        OLD.updated_at,
        OLD.location,
        OLD.paid_amount,
        OLD.rating,
        OLD.approx_cost,
        OLD.requested_amount
    );
END;

