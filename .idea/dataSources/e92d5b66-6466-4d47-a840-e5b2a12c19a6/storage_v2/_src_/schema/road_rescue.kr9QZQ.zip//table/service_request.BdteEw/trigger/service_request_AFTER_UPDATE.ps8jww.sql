create definer = admin@`%` trigger service_request_AFTER_UPDATE
    after update
    on service_request
    for each row
BEGIN
	IF NEW.status = '3' THEN
        UPDATE technician
        SET status = 1
        WHERE service_provider_id = NEW.assigned_service_provider_id;
    END IF;

END;

