create definer = admin@`%` trigger service_provider_BEFORE_DELETE
    before delete
    on service_provider
    for each row
BEGIN
    INSERT INTO deleted_accounts (
        deleted_account_id,
        phone_number,
        email,
        f_name,
        type,
        l_name
    ) VALUES (
        OLD.id,
        OLD.phone_number,
        OLD.email,
        OLD.garage_name,
        OLD.type,
        OLD.owner_name
    );
END;

