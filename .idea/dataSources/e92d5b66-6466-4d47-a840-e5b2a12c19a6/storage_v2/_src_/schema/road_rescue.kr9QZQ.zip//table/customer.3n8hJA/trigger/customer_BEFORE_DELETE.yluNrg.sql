create definer = admin@`%` trigger customer_BEFORE_DELETE
    before delete
    on customer
    for each row
BEGIN
    INSERT INTO deleted_accounts (
        deleted_account_id,
        phone_number,
        email,
        f_name,
        type,
        l_name
    ) VALUES (
        OLD.id,
        OLD.phone_number,
        OLD.email,
        OLD.f_name,
        'customer',
        OLD.l_name
    );

END;

