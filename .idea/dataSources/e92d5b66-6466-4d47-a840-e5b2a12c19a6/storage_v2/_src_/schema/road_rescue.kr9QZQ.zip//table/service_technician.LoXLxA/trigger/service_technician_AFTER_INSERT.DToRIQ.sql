create definer = admin@`%` trigger service_technician_AFTER_INSERT
    after insert
    on service_technician
    for each row
BEGIN
UPDATE technician
    SET status = 2
    WHERE id = NEW.technician_id;
END;

